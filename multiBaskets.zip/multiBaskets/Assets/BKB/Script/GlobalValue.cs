﻿using UnityEngine;
using System.Collections;

public class GlobalValue : MonoBehaviour {
	public static string Stars = "Stars";
	public static string Points = "Points";
	public static string ModeNormal = "ModeNormal";
	public static string ModeSliding = "ModeSliding";
	public static string ModeDual = "ModeDual";

	public static string ChoosenBall = "ChoosenBall";

	public static int combo = 1;
//	public static bool isSound = true;
//	public static bool isMusic = true;
//	public static bool isRestart = false;

}
