﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;

public class Change : MonoBehaviour {
	public Transform mainMenu, optionsMenu;

	// Update is called once per frame
	public void changeToScene (string sceneTochangeTo)
	{
		//Application.LoadLevel (sceneTochangeTo);

		SceneManager.LoadScene (sceneTochangeTo);
	}

	public void QuitGame(){
		Application.Quit ();
	}

	public void OptionsMenu (bool clicked){
		if (clicked == true) {
			optionsMenu.gameObject.SetActive (clicked);
			mainMenu.gameObject.SetActive (false);
		} else {
			optionsMenu.gameObject.SetActive (clicked);
			mainMenu.gameObject.SetActive (true);
		}
	}
		
}
